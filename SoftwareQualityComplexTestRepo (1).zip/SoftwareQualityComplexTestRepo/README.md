# Complex Java test repository for Software Quality Analyzer

Synthetic test fixture with multiple classes, branching, coupling, cohesion, public attributes, duplicated code, unused fields, file handling, and exception handling. It is not production software.

Upload `SoftwareQualityComplexTestRepo.zip` to test Java source metrics, static analysis, dashboards, recommendations, PDF export, and (because `.git` is included) Git/process metrics. Process metrics require the analyzer to read Git history. ML prediction/SHAP require a compatible trained model and valid labels; this code repository alone does not provide training labels.

Metric status should distinguish Calculated, Not Applicable, Unavailable, and Calculation Error rather than reporting unsupported values as zero.
