package com.example.shop;
public class Customer {
 public String customerCode; private String name; private String email; private int loyaltyPoints;
 public Customer(String code,String name,String email){this.customerCode=code;this.name=name;this.email=email;}
 public String getName(){return name;} public String getEmail(){return email;} public int getLoyaltyPoints(){return loyaltyPoints;}
 public void addPoints(int points){if(points>0)loyaltyPoints+=points;}
}
