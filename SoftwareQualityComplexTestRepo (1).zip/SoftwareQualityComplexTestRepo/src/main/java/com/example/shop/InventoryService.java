package com.example.shop;
import java.util.HashMap; import java.util.Map;
public class InventoryService {
 private final Map<String,Product> products=new HashMap<>(); private int updates;
 public void register(Product p){if(p==null)throw new IllegalArgumentException("product");products.put(p.sku,p);}
 public boolean reserve(String sku,int q){Product p=products.get(sku);if(p==null||q<=0)return false;if(p.getStock()<q)return false;p.setStock(p.getStock()-q);updates++;return true;}
 public boolean restock(String sku,int q){Product p=products.get(sku);if(p==null||q<=0)return false;p.setStock(p.getStock()+q);updates++;return true;}
 public int getUpdates(){return updates;}
}
