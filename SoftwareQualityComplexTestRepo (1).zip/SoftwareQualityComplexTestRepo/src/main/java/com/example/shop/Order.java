package com.example.shop;
import java.util.ArrayList; import java.util.List;
public class Order {
 public String orderId; private Customer customer; private final List<Product> products=new ArrayList<>(); private String status="NEW";
 public Order(String id,Customer customer){this.orderId=id;this.customer=customer;}
 public Customer getCustomer(){return customer;} public List<Product> getProducts(){return products;}
 public String getStatus(){return status;} public void setStatus(String status){this.status=status;}
 public void addProduct(Product p){products.add(p);}
 public double total(){double sum=0;for(Product p:products)sum+=p.getPrice();return sum;}
}
