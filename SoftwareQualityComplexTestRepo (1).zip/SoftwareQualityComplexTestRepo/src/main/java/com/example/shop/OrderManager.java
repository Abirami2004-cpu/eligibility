package com.example.shop;
import java.io.BufferedReader; import java.io.FileReader; import java.io.IOException;
import java.util.ArrayList; import java.util.HashMap; import java.util.List; import java.util.Map;

/** Intentionally oversized demo class containing analyzable complexity and code smells. Not production code. */
public class OrderManager {
 public String lastStatus; public int debugFlag=1;
 private final List<Order> orders=new ArrayList<>(); private final Map<String,Customer> customers=new HashMap<>();
 private final Map<String,String> auditLog=new HashMap<>(); private final InventoryService inventory=new InventoryService();
 private final PaymentProcessor payment=new PaymentProcessor("DemoProvider"); private int successfulOrders; private int failedOrders;
 private String cachedReport;
 public void addCustomer(Customer c){if(c!=null)customers.put(c.customerCode,c);}
 public void addOrder(Order o){if(o==null){lastStatus="NULL_ORDER";return;}orders.add(o);lastStatus="ORDER_ADDED";}

 public String processOrder(String orderId,String method,String token){
  Order selected=null; for(Order o:orders){if(o.orderId!=null&&o.orderId.equals(orderId)){selected=o;break;}}
  if(selected==null){failedOrders++;lastStatus="ORDER_NOT_FOUND";return lastStatus;}
  Customer c=selected.getCustomer(); if(c==null){failedOrders++;lastStatus="NO_CUSTOMER";return lastStatus;}
  if(selected.getProducts().isEmpty()){failedOrders++;lastStatus="EMPTY_ORDER";return lastStatus;}
  double total=0;int count=0;
  for(Product p:selected.getProducts()){
   if(p==null){failedOrders++;lastStatus="NULL_PRODUCT";return lastStatus;}
   if(p.getPrice()<0){failedOrders++;lastStatus="INVALID_PRICE";return lastStatus;}
   if(!p.isAvailable()){failedOrders++;lastStatus="OUT_OF_STOCK";return lastStatus;}
   total+=p.getPrice();count++;
  }
  if(count>10&&total>1000){if(c.getLoyaltyPoints()>500)total*=.90;else if(c.getLoyaltyPoints()>100)total*=.95;else total*=.98;}
  else if(total>5000){lastStatus="MANUAL_REVIEW";auditLog.put(orderId,"large order");return lastStatus;}
  String result;
  try{result=payment.charge(c,total,method,token);}
  catch(IllegalArgumentException ex){lastStatus="PAYMENT_INPUT_ERROR";failedOrders++;auditLog.put(orderId,ex.getMessage());return lastStatus;}
  catch(RuntimeException ex){lastStatus="PAYMENT_RUNTIME_ERROR";failedOrders++;return lastStatus;}
  if(result.endsWith("APPROVED")||result.endsWith("ACCEPTED")){selected.setStatus("PAID");c.addPoints((int)total/10);successfulOrders++;lastStatus="SUCCESS";auditLog.put(orderId,result);}
  else if(result.contains("REVIEW")){selected.setStatus("REVIEW");lastStatus="REVIEW";auditLog.put(orderId,result);}
  else{selected.setStatus("FAILED");failedOrders++;lastStatus="PAYMENT_FAILED";auditLog.put(orderId,result);}
  return lastStatus;
 }

 public String importCustomers(String path){
  int imported=0;
  try(BufferedReader reader=new BufferedReader(new FileReader(path))){String line;
   while((line=reader.readLine())!=null){String[] f=line.split(",");if(f.length>=3){Customer c=new Customer(f[0].trim(),f[1].trim(),f[2].trim());customers.put(c.customerCode,c);imported++;}}
   lastStatus="IMPORTED_"+imported;
  }catch(IOException ex){lastStatus="IMPORT_ERROR";auditLog.put(path,ex.getClass().getSimpleName());}
  return lastStatus;
 }

 public String buildSummaryReport(){
  StringBuilder r=new StringBuilder();r.append("Orders=").append(orders.size()).append("\n");
  r.append("Customers=").append(customers.size()).append("\n");r.append("Success=").append(successfulOrders).append("\n");
  r.append("Failed=").append(failedOrders).append("\n");r.append("InventoryUpdates=").append(inventory.getUpdates()).append("\n");
  r.append("PaymentAttempts=").append(payment.getAttempts()).append("\n");
  for(Order o:orders){r.append(o.orderId).append(":").append(o.getStatus()).append("\n");for(Product p:o.getProducts())if(p!=null)r.append("  ").append(p.getName()).append(" $").append(p.getPrice()).append("\n");}
  cachedReport=r.toString();return cachedReport;
 }
 public List<String> findOrdersByStatus(String status){List<String> out=new ArrayList<>();for(Order o:orders)if(o.getStatus()!=null&&o.getStatus().equals(status))out.add(o.orderId);return out;}
 public int countOrdersByCustomer(String code){int n=0;for(Order o:orders){Customer c=o.getCustomer();if(c!=null&&c.customerCode!=null&&c.customerCode.equals(code))n++;}return n;}
 public boolean cancelOrder(String id,String reason){
  for(Order o:orders){if(o.orderId!=null&&o.orderId.equals(id)){if(o.getStatus().equals("PAID")){lastStatus="REFUND_REQUIRED";auditLog.put(id,"cancel:"+reason);return false;}
   else if(o.getStatus().equals("CANCELLED")){lastStatus="ALREADY_CANCELLED";return false;}
   else{o.setStatus("CANCELLED");auditLog.put(id,"cancel:"+reason);lastStatus="CANCELLED";return true;}}}
  lastStatus="NOT_FOUND";return false;
 }
 public void loadInventory(List<Product> items){for(Product p:items)if(p!=null)inventory.register(p);}
 public boolean reserveProduct(String sku,int q){return inventory.reserve(sku,q);}
 public boolean restockProduct(String sku,int q){return inventory.restock(sku,q);}
 public int getSuccessfulOrders(){return successfulOrders;} public int getFailedOrders(){return failedOrders;}
 public List<Order> getOrders(){return orders;} public Map<String,String> getAuditLog(){return auditLog;}
 public String formatCustomerLine(Customer c){if(c==null)return "customer:null";return "customer:"+c.customerCode+":"+c.getName()+":"+c.getEmail();}
 public String formatCustomerLineAgain(Customer c){if(c==null)return "customer:null";return "customer:"+c.customerCode+":"+c.getName()+":"+c.getEmail();}
}
