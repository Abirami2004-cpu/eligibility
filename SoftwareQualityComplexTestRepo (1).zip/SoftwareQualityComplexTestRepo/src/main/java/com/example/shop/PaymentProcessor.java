package com.example.shop;
import java.util.Locale;
public class PaymentProcessor {
 private final String providerName; private int attempts;
 public PaymentProcessor(String providerName){this.providerName=providerName;}
 public String charge(Customer customer,double amount,String method,String token){
  attempts++; if(customer==null)throw new IllegalArgumentException("customer is required");
  if(amount<=0)return "REJECTED_AMOUNT"; if(method==null||method.trim().isEmpty())return "REJECTED_METHOD";
  String normalized=method.toLowerCase(Locale.ROOT);
  if(normalized.equals("card")){if(token==null||token.length()<8)return "REJECTED_TOKEN";if(amount>1000&&customer.getLoyaltyPoints()<100)return "REVIEW";return "CARD_APPROVED";}
  else if(normalized.equals("wallet")){if(token==null)return "REJECTED_TOKEN";return amount>500?"WALLET_REVIEW":"WALLET_APPROVED";}
  else if(normalized.equals("cash"))return amount>2000?"CASH_REVIEW":"CASH_ACCEPTED";
  else return "UNKNOWN_METHOD";
 }
 public String getProviderName(){return providerName;} public int getAttempts(){return attempts;}
}
