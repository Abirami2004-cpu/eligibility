package com.example.shop;
public class Product {
 public String sku; private String name; private double price; private int stock; private String internalNote;
 public Product(String sku,String name,double price,int stock){this.sku=sku;this.name=name;this.price=price;this.stock=stock;}
 public String getName(){return name;} public double getPrice(){return price;} public int getStock(){return stock;}
 public void setStock(int stock){this.stock=stock;} public boolean isAvailable(){return stock>0;}
}
