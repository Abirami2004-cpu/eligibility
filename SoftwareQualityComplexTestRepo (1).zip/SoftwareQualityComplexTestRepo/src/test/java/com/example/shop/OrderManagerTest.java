package com.example.shop;
import org.junit.jupiter.api.Test; import static org.junit.jupiter.api.Assertions.*;
class OrderManagerTest {
 @Test void addsAndFindsOrder(){OrderManager m=new OrderManager();Customer c=new Customer("C1","Sample","sample@example.test");Order o=new Order("O1",c);m.addOrder(o);assertEquals(1,m.getOrders().size());assertEquals(1,m.countOrdersByCustomer("C1"));}
}
